// https://www.learncpp.com/cpp-tutorial/15-1-intro-to-smart-pointers-move-semantics/
#include <iostream>

template<class T>
class my_auto_ptr{
	T* m_ptr;
	std::string m_name;
public:
	// Pass in a pointer to "own" via the constructor
	my_auto_ptr(std::string name, T* ptr = nullptr) : m_ptr(ptr), m_name(name) {
		std::cout << m_name << " constructor" << std::endl;
	}
	my_auto_ptr(my_auto_ptr &ptr){
		std::cout << ptr.m_name << " deep copy constructor" << std::endl;
		m_name = ptr.m_name;
		m_ptr = new T;
		*m_ptr = *ptr.m_ptr;
	}	
	my_auto_ptr& operator=(const my_auto_ptr& ptr){
		std::string old_name = m_name;
		std::cout << "assignment: " << m_name << "<-" << ptr.m_name << std::endl;
		// Self-assignment detection
		if (this == &ptr)
			return *this; 
		delete m_ptr;
		// Copy the resource
		m_ptr = new T;
		m_name = ptr.m_name + " was " + m_name;
		*m_ptr = *ptr.m_ptr;
		std::cout << old_name << " is now " << m_name << std::endl;
		return *this;
	}
	~my_auto_ptr(){
		std::cout << m_name << " destructor" << std::endl;
		delete m_ptr;
	}
	// Overload dereference and operator-> so we can use Auto_ptr1 like m_ptr.
	T& operator*() const { return *m_ptr; }
	T* operator->() const { return m_ptr; }
};

// A sample class to prove the above works
class Resource {
  public:
	Resource() { std::cout << "Resource created\n"; }
	~Resource() { std::cout << "Resource destroyed\n"; }
	void* operator new(size_t size) {
		std::cout << "new Resource: size: " << size << std::endl;
		void* p = malloc(size);
		return p;
	}
	void operator delete(void* p) {
		std::cout << "delete Resource" << std::endl;
		free(p);
	}
};

my_auto_ptr<Resource> generateResource() {
	std::cout << "in genereteResource()" << std::endl;
	std::cout << "==generateResource:1================" << std::endl;
	my_auto_ptr<Resource> localres("localres", new Resource);
	std::cout << "==generateResource:2================" << std::endl;
	return localres; // this return value will invoke the move constructor
}

int main(){
	std::cout << "==main:1============================" << std::endl;
	my_auto_ptr<Resource> res1("res1", new Resource());
	std::cout << "==main:2============================" << std::endl;
	my_auto_ptr<Resource> res2("res2", new Resource());
	std::cout << "==main:3============================" << std::endl;
	//res1 = res2; // illegal because res2 is an lvalue
	res1 = my_auto_ptr<Resource>("anonymous", new Resource());
	std::cout << "==main:4============================" << std::endl;
	my_auto_ptr<Resource> mainres("mainres");
	std::cout << "==main:5============================" << std::endl;
	mainres = generateResource(); // this assignment will invoke the move assignment
	std::cout << "==main:6============================" << std::endl;
	return 0;
}