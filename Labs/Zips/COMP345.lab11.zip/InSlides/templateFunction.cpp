#include <iostream>
using namespace std;

template <class T>
T max(T a, T b)
{
	cout << "Using template for type : " << typeid(a).name() << endl;
	return a > b ? a : b;
}

template <>
const char* max(const char* a, const char* b)
{
	cout << "Using specialized template for argument type : " << typeid(a).name() << endl;
	return strcmp(a, b) > 0 ? a : b;
}

void main()
{
	cout << "max(10, 15) = " << max(10, 15) << endl;
	cout << "max('k', 's') = " << max('k', 's') << endl;
	cout << "max(10.1, 15.2) = " << max(10.1, 15.2) << endl;
	cout << "max(\"Foo\", \"Bar\") = " << max("Foo", "Bar") << endl;
	int i; cin >> i;
}

//int max(int a, int b) {
//	return a > b ? a : b;
//}

//char max(char a, char b) {
//	return a > b ? a : b;
//}

//float max(float a, float b) {
//	return a > b ? a : b;
//}