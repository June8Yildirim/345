#pragma once
#include <iostream>
using namespace std;

template <typename T>
class Stack
{
public:
	Stack(int = 10);
	~Stack() { delete[] stackPtr; }
	int push(const T&);
	int pop(T&);  
	int isEmpty()const { return top == -1; }
	int isFull() const { return top == size - 1; }
private:
	int size;  
	int top;
	T* stackPtr;
};

template <typename T> 
ostream& operator<<( ostream& output, Stack<T> stack);
