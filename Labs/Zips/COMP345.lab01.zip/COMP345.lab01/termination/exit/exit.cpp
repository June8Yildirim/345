#include<stdlib.h>
int main() {
	// The exit() function can be used to terminate the program. 
	// The exit() function is part of the stdlib.h library. 
	// Calling the exit() in the main function is functionally equivalent to return(). 
	exit (0); 
}