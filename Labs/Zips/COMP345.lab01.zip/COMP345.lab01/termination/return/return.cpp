int main() {
	// When the main function returns, the program is terminated. 
	// By convention, returning 0 signifies the end of a correct execution. 
	return(0); 
}