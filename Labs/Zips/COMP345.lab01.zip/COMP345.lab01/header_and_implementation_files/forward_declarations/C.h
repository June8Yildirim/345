#pragma once
class C {

};