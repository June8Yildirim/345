#include "Boiler.h"
#include <iostream>
using namespace std;

int main() {
	Boiler b;
	b.start();

	int j;  cin >> j;
}