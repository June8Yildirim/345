#pragma once
enum ActuatorState { opened, closed };
enum BoilerState { safe, unsafe, critical };
enum HardwareState { operational, stuck };