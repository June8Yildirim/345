#include<iostream>
using namespace std;
#include "A.h"
#include "B.h"

int main(){
	A a;
	B b;
	a.show(a, b);
	return 0;
}
